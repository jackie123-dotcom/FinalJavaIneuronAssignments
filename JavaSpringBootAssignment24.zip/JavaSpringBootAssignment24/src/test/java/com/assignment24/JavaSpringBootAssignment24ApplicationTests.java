package com.assignment24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringBootAssignment24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
