package com.hibernate.assignment18;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.internal.build.AllowSysOut;

public class HibernateQuestion18 {
	
	public static void main(String[] args) {
		try {
			Configuration config = new Configuration();
			
			config.configure("hibernate.cfg.xml");

			
			SessionFactory sessionFactory = config.buildSessionFactory();

			Session session = sessionFactory.openSession();
			
			List person = new ArrayList<>();

			List list = session.createQuery("from Person").list();
			
			Iterator it = list.iterator();
			
			while(it.hasNext()) {
				Object ob = (Object)it.next();
				
				Person p = (Person)ob;
				
				System.out.println("id" + p.getId());
				System.out.println("id" + p.getName());
				System.out.println("id" + p.getAge());
			}
            sessionFactory.close();
			session.close();
			
		}catch(Exception e) {
			System.out.println(e);
		}
			
		}
}


