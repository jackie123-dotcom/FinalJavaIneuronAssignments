package com.assignment15;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/assignment15")
public class QuestionAssignment15 extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			response.setContentType("text/html");

			PrintWriter out = response.getWriter();
			out.println("");

			try {
				
			String url = "jdbc:mysql://localhost:3306/AssignmentNumber15";
			String username = "root";
			String password = "admin";

			Connection conn = DriverManager.getConnection(url, username, password);

			Statement stmt = conn.createStatement();
			ResultSet res = stmt.executeQuery("SELECT * FROM employeeDetail");

			out.println("");
			out.println("");

			while (res.next()) {
				
			int id = res.getInt("id");
			String name = res.getString("name");
			double salary = res.getDouble("salary");

			out.println("");
			
		}

			out.println("ID	Name Salary\n"
					+ "	\" + id + \"\" + name + \"	\" + salary + \"\n");

			res.close();
			stmt.close();
			conn.close();

			} catch (SQLException e) {
			e.printStackTrace();
			}

			out.println("");
			}
			}
