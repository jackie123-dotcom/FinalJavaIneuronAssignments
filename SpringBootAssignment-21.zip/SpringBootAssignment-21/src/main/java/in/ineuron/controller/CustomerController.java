package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;

import in.ineuron.model.Customer;
import in.ineuron.service.CustomerService;

@RestController
@RequestMapping("/api")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/save")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) {
		
		Customer customer1 = customerService.addCustomer(customer);
		
	      return new ResponseEntity<>(customer1,HttpStatus.CREATED); 
	}
	
	@GetMapping("/find")
	public String findAllcustomers(Customer customer) {
		
		return "customers"; 
	}
	
	@PutMapping("/update")
	public Customer udateCustomer(Customer customer) {
		
		return customerService.updateCustomer(customer) ;
	}
	
	@DeleteMapping("/delete")
	public boolean deleteCustomerById(Customer customer) {
		int customerId = 0;
		if(customerId == customer.getId()) {
			System.out.println("Customer was not deleted successfully");
		}
		
		return false;
		
	}

}
