package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Customer;

public interface CustomerServiceImpl {
	
	public Customer addCustomer(Customer customer);
	
	public List<Customer> findAllCustomers();
	
	public Customer findCustomerById(Customer customer);
	
	public Customer updateCustomer(Customer customer);
	
	public void deleteCustomer(Customer customer);

}
