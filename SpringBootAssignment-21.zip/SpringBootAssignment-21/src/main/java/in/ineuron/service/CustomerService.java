package in.ineuron.service;

import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.model.Customer;
import in.ineuron.repository.CustomerRepository;

@Service
public class CustomerService implements CustomerServiceImpl{
	
	private final CustomerRepository customerRepo;
	
	public CustomerService(CustomerRepository customerRepo) {
		this.customerRepo = customerRepo;
		
	}
	
	
	public Customer addCustomer(Customer customer) {
		return customer;
		
		
	}
	@Override
	public List<Customer> findAllCustomers() {
		
		return customerRepo.findAll();
	}


	@Override
	public Customer findCustomerById(Customer customer) {
		
		Integer newId = 0;
		if(newId == customer.getId() )
		newId = customer.getId();
		
		return customer;
	}


	@Override
	public Customer updateCustomer(Customer customer) {
		
		return customer;
	}


	@Override
	public void deleteCustomer(Customer customer) {
		
		customerRepo.delete(customer);
	}

}
