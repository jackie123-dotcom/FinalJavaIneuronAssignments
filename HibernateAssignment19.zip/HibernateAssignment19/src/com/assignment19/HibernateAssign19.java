package com.assignment19;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class HibernateAssign19 {

	public static void main(String[] args) {
		
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = config.buildSessionFactory();

		Session session = sessionFactory.openSession();

		Transaction tx = session.beginTransaction();

		Student student = new Student();
		student.setName("Jackie");
		student.setAge(29);
		
		student.setName("Sachin");
		student.setAge(42);

		session.save(student);

		tx.commit();

		Student retrievedStudent = session.get(Student.class, 1);
		System.out.println("Retrieved student: " + retrievedStudent);

		session.close();
		sessionFactory.close();
	}	
}
