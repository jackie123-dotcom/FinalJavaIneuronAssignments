package com.assignment9;

import java.util.Queue;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;

public class ProducerConsumerExample {
	
    public static void main(String[] args) {
	
        Queue queue = new LinkedBlockingQueue<>();

        Producer producer = new Producer(queue);

        Consumer consumer = new Consumer(queue);

        Thread producerThread = new Thread(producer);

        Thread consumerThread = new Thread(consumer);

             producerThread.start();
             
             consumerThread.start();
   }
}

 class Producer implements Runnable {
	 
     private Queue queue;
     
     private Random random;

     public Producer(Queue queue) {
    	 
     this.queue = queue;
     this.random = new Random();
 }

     public void run() {
    	 
        while (true) {
	
        int num = random.nextInt(100);

        synchronized (queue) {
	
        queue.add(num);

          System.out.println("Produced " + num);
        queue.notifyAll();
  }
         try {
        	 
            Thread.sleep(1000);
            
         } catch (InterruptedException e) {
            e.printStackTrace();
        }
      }
    }
 }

 class Consumer implements Runnable {
      private Queue queue;

      public Consumer(Queue queue) {
    	  
          this.queue = queue;
 }

      public void run() {
    	  
      while (true) {
    	  
      synchronized (queue) {
    	  
      while (queue.isEmpty()) {
    	  
        try {
        	
           queue.wait();
           
         } catch (InterruptedException e) {
            e.printStackTrace();
       }
     }
      int sum = 0;
      
      while (!queue.isEmpty()) {
    	  
        sum += queue.remove();
     }
           System.out.println("Consumed " + sum);
    }
   }
  }
}