package com.assignment5;

public class AbstractAndInterfaceDemo {
	
	public static void main(String[]args) {
		Person p = new Child();
		p.printPersonDetails();
		
		Child ch = new Child();
		
		ch.eat();
		ch.walk();
	}

}
/*
 * KEY POINTS TO CONSIDER
 * Abstract class can not be instatiated directly but only through a subclass that will 
 * extend it and  implement all the methods there in.
 * Abstract class can have a constructor
 * Abstract class can have both non abstract and abstract methods
 * if only one abstract method in class, then it must be declared abstract
 * Abstract class can have fields and constants.
 * 
 * WHEREAS INTERFACE
 * An interface, on the other hand, is a collection of abstract methods that define a contract for what a class can do.
 * It can only have abstract methods, no fields or constants but only method signatures.
 * Classes implement interfaces by providing implementations for all of the methods defined in the interface.
 * 
 */
 abstract class Person {
	 
	private int age = 20;
	 
	 private String name = "Rahul";
	 
	 private String address = "Mi";
	 
	 public Person() {
		super();
	}

	public Person(int age, String name, String address) {
		super();
		this.age = age;
		this.name = name;
		this.address = address;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	

	public abstract void printPersonDetails();
	 
}
 
interface Employee{
	 
	 void eat();
	 
	 void walk();
	 
 }
 
 class Child extends Person implements Employee {

	@Override
	public void printPersonDetails() {
		
		Person p = new Child();
		p.setAge(20);
		
		p.setName("Jane");
		
		p.setAddress("MI");
		
		System.out.println(p.getAge());
		System.out.println(p.getName());
		System.out.println(p.getAddress());
		
	}

	@Override
	public void eat() {
		System.out.println("I love eating Avocadoes");
		System.out.println("Eating healthy is really good for the body");
		
	}

	@Override
	public void walk() {
		System.out.println("Taking a walk quite often is considered exercise which is also good for the body");
	}

 }
 
 
