package com.assignment10;

import java.util.*;

   public class ReadSetOfIntegers {
	
       public static void main(String[] args) {
           
    	   Scanner scanner = new Scanner(System.in);

        // Read integers from user and store them in a List
           List list = new ArrayList<>();
            
           System.out.print("Enter integers (one per line, empty line to stop): ");
           
           int num = scanner.nextInt();
              
            String line;
             
               
             
              while (!(line = scanner.nextLine()).isEmpty()) {
               int number = Integer.parseInt(line);
                 
                 list.add(number);
                 
                 }
              
            	 
            // Find second largest and second smallest elements in the List
             
             int secondLargest = Integer.MIN_VALUE;
             int largest = Integer.MIN_VALUE;
             int secondSmallest = Integer.MAX_VALUE;
             int smallest = Integer.MAX_VALUE;
             
             for (int number = 0; number <= list.size(); number++) {
            	 
                 if (number > largest) {
                	 
                     secondLargest = largest;
                     largest = number;
                     
                   } else if (number > secondLargest && number != largest) {
                	   
                       secondLargest = number;
                       
                       }
                 
                 if (number < smallest) {
                	 
                     secondSmallest = smallest;
                     smallest = number;
                     
                     
                   } else if (number < secondSmallest && number != smallest) {
                	   
                      secondSmallest = number;
                      
                      }
                 
                 }
             
               System.out.printf("Second largest: %d%n", secondLargest);
               System.out.printf("Second smallest: %d%n", secondSmallest);
               
              }
       }