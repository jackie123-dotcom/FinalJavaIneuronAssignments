package com.assignment3;

import java.util.Scanner;

public class ExceptionHandling {

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter an integer of your choice");
			
			int num = sc.nextInt();
			
			if(num < 0) {
				
				throw new Exception("number integer entered should not be negative");
			}
				System.out.println("Your number choice is:" + num);
			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

	}

}
