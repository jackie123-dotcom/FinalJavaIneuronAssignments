package com.assignment6;

import java.util.Arrays;
import java.util.List;

public class StreamApiOperations {
	
      public static void main(String[] args) {
    	  
         List<Person> people = Arrays.asList(
        		 
            new Person("John", 25, 50000),
            new Person("Mary", 30, 60000),
            new Person("Bob", 35, 45000),
            new Person("Alice", 40, 70000),
            new Person("David", 45, 55000)
         );

       List<Person> filteredAndSortedPeople = people.stream()
    		   
          .filter(p -> ((Person) p).getSalary() >= 50000)
          .sorted((p1, p2) -> ((Person) p1).getAge() - ((Person) p2).getAge())
          .toList();

             System.out.println(filteredAndSortedPeople);
      }
   }

 class Person {
	 
     private String name;
     
     private int age;
     
     private int salary;

   public Person(String name, int age, int salary) {
	   
       this.name = name;
       this.age = age;
       this.salary = salary;
    }

   public String getName() {
      return name;
     }

   public int getAge() {
	   
      return age;
      
     }

   public int getSalary() {
       return salary;
    }

     @Override
   public String toString() {
    	 
         return "Person{" +  "name='" + name + '\'' +
                 ", age=" + age +
                 ", salary=" + salary +
                 
                 '}';
   }
}
