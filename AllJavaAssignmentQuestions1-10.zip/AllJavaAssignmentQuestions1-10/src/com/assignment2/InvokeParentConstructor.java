package com.assignment2;

public class InvokeParentConstructor {
	
	public static void main(String[] args) {
		
		Child ch = new Child();
		
	}
}
/*
 * A constructor is a special type of method that is called when an object of a particular
 * class is being instantiated.
 * It must be the same name as the class and must not have a return type.
 * it can have parameters or can be parameterless
 * If there is no constructor given in the program, there will always be a default constructor
 * provided for you by the compiler.
 */
class Parent{
	
	public Parent() {
		System.out.println("This is parent constructor being invoked");
	}
}

class Child extends Parent{
	
	public Child() {
		super();
		
		System.out.println("Hello there!!!");
		
		System.out.println("This is child constructor invoked!!");
	}
}
