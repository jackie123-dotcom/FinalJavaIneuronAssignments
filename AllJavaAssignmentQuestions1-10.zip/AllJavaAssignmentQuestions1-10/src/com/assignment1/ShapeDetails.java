package com.assignment1;

public class ShapeDetails {

	public static void main(String[] args) {
		
		Shape sp = new Circle();//Polymorphism, Shape can be written in many different forms as a circle and as a triangle
		 sp.calcArea();
		 System.out.println();
		 
		 sp.calcPerimeter();
		 System.out.println();
		 
		 Shape sp1 = new Triangle();
		 sp1.calcArea();
		 
		 System.out.println();
		 
		 sp1.calcPerimeter();

	}

}

 interface Shape {
	
	void calcArea();
	
	void calcPerimeter();
	
}

class Circle implements Shape{

	@Override
	public void calcArea() {
		
		double radius = 2.4;
		
		double areaCircle = 3.1416 * radius * radius;
		
		//double perimeter = 2 * 3.1416 * radius;
		
		System.out.println("The area of a Circle is: " + areaCircle);
	}

	@Override
	public void calcPerimeter() {
		
		double radius = 2.4;
		
		//double area = 3.1416 * radius * radius;
		
		double perimeterCircle = 2 * 3.1416 * radius;
		
		System.out.println("The perimeter of a Triangle is: " + perimeterCircle);
	}
	
}

class Triangle implements Shape{

	@Override
	public void calcArea() {
		
		int base = 4;
		
		int height = 3;
		
		int side = 6;
		
		int areaTriangle = (base * height)/2;
		
		System.out.println("The area of a Triangle is: " + areaTriangle);
		
		//int perimeter = side + base + side;
		
	}

	@Override
	public void calcPerimeter() {
		
		int base = 4;
		
		int side = 6;
		
		int perimeterTriangle = side + base + side;
		
		System.out.println("The perimeter of a Triangle is: " + perimeterTriangle);
		
	}
	
}

