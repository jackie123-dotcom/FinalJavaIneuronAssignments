package com.assignment8;

public class ThreadPrintNumbers {

	public static void main(String[] args) {
		//create threads
		Thread t1 = new Thread(new PrintEvenNumbers());
		Thread t2 = new Thread(new PrintOddNumbers());
		
		t1.start();
		
		t2.start();

	}

}

class PrintEvenNumbers implements Runnable{
	
	
	@Override
	public void run() {
		
		for(int i = 2; i <= 10; i+=2 ) {
			System.out.println(i);
		}
		System.out.println();
		
	}
}

class PrintOddNumbers implements Runnable{

	@Override
	public void run() {
		
		for(int i = 1; i <= 9; i+=2) {
			System.out.println(i);
		}
		
	}
	
}
