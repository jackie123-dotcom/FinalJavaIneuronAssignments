package assignment.question11;

import java.sql.*;
import java.sql.DriverManager;

public class QuestionNumber11 {

	public static void main(String[] args) {
		/*
		 * JDBC connection steps are;
		 * 1. Load the Mysql Jdbc driver using Class.forName(); method.
		 * 2. Establish the connection using the DriverManager.getConnection() method
		 * 3. Create the statement object using connection.createStatement() method
		 * 4. Execute the Sql query using staement.executeQuery() method
		 * 5. Prepare the ResultSet object returned by the query and display the results
		 * 6. Close the resource.
		 */
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/assignment11";
			
			String userName = "root";
			
			String password = "admin";
			
			Connection con = DriverManager.getConnection(url, userName, password);
			
			Statement statement = con.createStatement();
			
			//Execute the query
			String query = "select * from niceEmptable";
			
			ResultSet resultSet = statement.executeQuery(query);
			
			while(resultSet.next()) {
				
				int id = resultSet.getInt("id");
				
				String name = resultSet.getString("name");
				
				int age = resultSet.getInt("age");
				
				System.out.println("Id" + id + "Name" + name + "Age" + age);
				
			}
			resultSet.close();
			statement.close();
			con.close();
				
		}
		catch(Exception se) {
			se.printStackTrace();
			
		}

	}

}
