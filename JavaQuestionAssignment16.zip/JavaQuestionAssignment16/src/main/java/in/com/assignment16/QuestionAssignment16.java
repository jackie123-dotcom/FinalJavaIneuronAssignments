package in.com.assignment16;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/trial")
public class QuestionAssignment16 extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			HttpSession session = request.getSession();

			String username = (String)session.getAttribute("username");
			
			if (username == null) {
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
		
			out.println("");
			out.println("Enter your name:");
			out.println("");
			
		} else {
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("");
			out.println("Welcome back, " + username + "!");
			out.println("");
		}
	}

			public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			
			HttpSession session = request.getSession();

			
			String username = request.getParameter("username");

			
			session.setAttribute("username", username);

			
			response.sendRedirect(request.getContextPath() + "/");
			
	 }
}