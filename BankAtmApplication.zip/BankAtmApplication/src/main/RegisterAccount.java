package main;

import model.UserAccount;

import java.util.*;



public class RegisterAccount {

    public static void accountRegister() {
        UserAccount account = new UserAccount();
        System.out.println("Enter account details ");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter account name");
        String name = sc.nextLine();
        account.setAccountHolderName(name);

        System.out.println("Enter Initial deposit ");
        double balanceAmount = sc.nextDouble();
        account.setBalanceAmount(balanceAmount);

        System.out.println("Enter account number ");
//		Random rand = new Random();
//		int accNo = Math.abs(rand.nextInt());
        int accNo = sc.nextInt();
        account.setAccountNumber(accNo);

        System.out.println("Enter account number to witthdraw money from: ");
//		Random rand = new Random();
//		int accNo = Math.abs(rand.nextInt());

        int accNoToWithdrawFrom = sc.nextInt();

        System.out.println("Enter amouunt to witthdraw: ");
//		Random rand = new Random();
//		int accNo = Math.abs(rand.nextInt());

        Double balance = account.getBalanceAmount();
        double amount = sc.nextDouble();
        if(amount < account.getBalanceAmount()) {
            account.setBalanceAmount(balance - amount);
            System.out.println("Youu have withdrawn " + amount + " and your new balance is " + account.getBalanceAmount());
        }else {
            System.out.println("Sorry you have insufficient balance");
        }

        System.out.println(account);
        //save in the database;


//		accounts.add(new UserAccount());

    }

    public static void deposit(UserAccount acc) {

        System.out.println("Enter Amount to Deposit:");

        Scanner sc = new Scanner(System.in);

        double amount = sc.nextDouble();

        acc.setBalanceAmount(acc.getBalanceAmount() + amount);
        System.out.println("D\neposit Successful!!!");

        printAccountDetails(acc);
    }

    public static void printAccountDetails(UserAccount acc) {
        System.out.println("\nAccount Details:");
        System.out.println("=======================");
        System.out.println("Account Name: " + acc.getAccountHolderName());
        System.out.println("Account Name: " + acc.getAccountNumber());
        System.out.println("Account Name: " + acc.getBalanceAmount());
    }

    public static boolean withdraw(UserAccount acc) {
        System.out.println("Enter amount to withdraw");

        Scanner sc = new Scanner(System.in);

        double amount = sc.nextDouble();

        if(acc.getBalanceAmount() < amount) {
            System.out.println("Sorry, you have insufficient balance!");

            return false;
        }

        acc.setBalanceAmount(acc.getBalanceAmount()-amount);
        System.out.println("Withdraw successful");
        printAccountDetails(acc);

        return true;
    }

    public static UserAccount getAccount(List<UserAccount> accounts) {

        System.out.println("\nEnter Your Account Name");

        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();

        for(UserAccount account: accounts) {
            if(name.equalsIgnoreCase(account.getAccountHolderName())) {
                System.out.println("\nAccount Found!!!");

                printAccountDetails(account);
                return account;
            }
        }

        System.out.println("\nSorry, this account has not been found.");
        return null;
    }

}
