package main;


import model.UserAccount;

import java.util.*;

public class BankAtmAccount {

	public static void main(String[] args) {
		
		System.out.println("********* Welcome to my Atm app **************");
		
//		UserAccount account = new UserAccount(1,"Muhind Sam","Bothell","smuhindo","hello","s@gmail.com","sam","22334",5785.9);
		List<UserAccount> accountPlus = new ArrayList<>();
//		accountPlus.add(account);
		
		boolean flag = true;

		while(flag) {
			printMenu();
			int choice = getChoice();
			
			switch(choice) {
				case 1: 
					RegisterAccount.accountRegister();
					break;			
				case 2: 
					UserAccount accDep = RegisterAccount.getAccount(accountPlus);
					if(accDep != null) {
						RegisterAccount.deposit(accDep);
					}
					break;	   	
				case 3: 
					UserAccount accWd = RegisterAccount.getAccount(accountPlus);
					if(accWd != null) {
						RegisterAccount.withdraw(accWd);
					}
					break;
				case 4:
					UserAccount accC = RegisterAccount.getAccount(accountPlus);
					
					if(accC != null) {
						RegisterAccount.printAccountDetails(accC);
					}
					break;

				case 5:
					UserAccount accDd = RegisterAccount.getAccount(accountPlus);

					if(accDd != null) {
						RegisterAccount.printAccountDetails(accDd);
					}
					break;

				case 0:
					System.out.println("You chose to quit.\nwas nice serving you, Bye,!!!");
					flag = false;
					break;
				default:
					System.out.println("Invalid Input Choice. Try again.");
					break;
			}
			System.out.println("\n..........................................\n");
		} 

		}
	
	public static void printMenu() {
		System.out.println("\nChoose  your option:");

		System.out.println("1. Register Account \n2. Deposit \n3. Withdraw \n4. Check Account \n5. check Balance \n0. Exit");
	}

	public static int getChoice() {
		System.out.println("\nEnter option: \n");
		Scanner sc = new Scanner(System.in);
		return sc.nextInt();
	}

}
