package model;
public class UserAccount {

    private Integer id;
    private String accountHolderName;
    private String userAddress;
    private String userName;
    private String password;
    private String emailAddress;
    private String pinNumber;
    private int accountNumber;
    private double balanceAmount;


    public UserAccount() {
        super();
    }


    public UserAccount(Integer id, String accountHolderName, String userAddress, String userName, String password,
                       String emailAddress, String pinNumber, int accountNumber, double balanceAmount) {
        super();
        this.id = id;
        this.accountHolderName = accountHolderName;
        this.userAddress = userAddress;
        this.userName = userName;
        this.password = password;
        this.emailAddress = emailAddress;
        this.pinNumber = pinNumber;
        this.accountNumber = accountNumber;
        this.balanceAmount = balanceAmount;

    }


    public double getBalanceAmount() {
        return balanceAmount;
    }


    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }


    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getAccountHolderName() {
        return accountHolderName;
    }
    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }
    public String getUserAddress() {
        return userAddress;
    }
    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public String getPinNumber() {
        return pinNumber;
    }
    public void setPinNumber(String pinNumber) {
        this.pinNumber = pinNumber;
    }
    public int getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
    @Override
    public String toString() {
        return "UserAccount [id=" + id + ", accountHolderName=" + accountHolderName + ", userAddress=" + userAddress
                + ", userName=" + userName + ", password=" + password + ", emailAddress=" + emailAddress
                + ", pinNumber=" + pinNumber + ", accountNumber=" + accountNumber + "]";
    }




}