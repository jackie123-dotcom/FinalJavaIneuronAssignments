package com.simpleapp.simpleRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
