package com.simpleapp.simpleRest.controller;

import com.simpleapp.simpleRest.model.Student;
import com.simpleapp.simpleRest.service.StudentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/student")
public class StudentController {
    private final StudentService studentService;


    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }
    @PostMapping("/save")
    public Student saveStudent(@RequestBody Student student){
        return  studentService.createStudent(student);
    }

    @GetMapping
    public List<Student> studentList(){
        return studentService.getAllStudents();
    }

}
