package com.assignment24.restAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
