package com.assignment24.restAPI.service;

import com.assignment24.restAPI.exceptions.PoductNotFoundException;
import com.assignment24.restAPI.model.Product;
import com.assignment24.restAPI.repository.ProductRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product createProduct(Product product){

        if (product.getManufactureDate().isAfter(product.getExpiredDate())){
            product.setIsExpired(true);
        }else {
            product.setIsExpired(false);
        }
        return productRepository.save(product);
    }

    public Product findProduct(Integer productId) throws PoductNotFoundException{
            Optional<Product> product = productRepository.findById(productId);
            if (product.isEmpty()) {
                throw new PoductNotFoundException("Sorry Product Does not exist with id " + productId);
            }
            return ResponseEntity.ok(product.get()).getBody();
        }

        public List<Product> findAllProducts(){
        return productRepository.findAll();
        }

    public void delete(Product product) {
        productRepository.delete(product);
    }
}
