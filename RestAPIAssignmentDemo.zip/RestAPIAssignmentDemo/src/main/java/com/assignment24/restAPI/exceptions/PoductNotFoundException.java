package com.assignment24.restAPI.exceptions;

public class PoductNotFoundException extends  Exception{
    public PoductNotFoundException(String message){
        super(message);
    }
}
