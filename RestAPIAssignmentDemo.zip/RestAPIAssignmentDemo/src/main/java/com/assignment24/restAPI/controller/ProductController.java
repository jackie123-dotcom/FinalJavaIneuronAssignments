package com.assignment24.restAPI.controller;

import com.assignment24.restAPI.exceptions.PoductNotFoundException;
import com.assignment24.restAPI.model.Product;
import com.assignment24.restAPI.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("api/v1/products")
public class ProductController {
    private  final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping(value = "/index")
    public String index() {
        return "index";
    }

    @GetMapping(value = "/register")
    public String showRegisterProductPage(Model model){
        model.addAttribute("p", new Product());
        return "register";
    }
    @PostMapping
    public String saveProduct(@ModelAttribute ("product") Product product, Model model){
         productService.createProduct(product);
         return "redirect:/api/v1/products/index";
    }

    @GetMapping
    public String products(Model model){
        model.addAttribute("products", productService.findAllProducts());
        return "products";
    }

    @GetMapping("/{productId}")
    public Product product(@PathVariable Integer productId){
        try {
            return productService.findProduct(productId);
        } catch (PoductNotFoundException e) {
            return null;
        }
    }

    @GetMapping("edit/{productId}")
    public String showUpdateForm(@PathVariable("productId") Integer productId, Model model){
        try {
            Product pt = productService.findProduct(productId);
            model.addAttribute("pt", pt);
        } catch (PoductNotFoundException e) {
            return String.valueOf(ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()));
        }
        return "updateProduct";
    }

    @PostMapping(value = {"/update/{id}"})
    public  String editStudent(@ModelAttribute Product product, Model model, @PathVariable Integer id, Integer productId, BindingResult result){
        product.setProductId(id);
        productService.createProduct(product);
        return "redirect:/api/v1/products";
    }

    @GetMapping("/delete/{productId}")
    public String deleteUser(@PathVariable("productId") Integer productId, Model model) {
        Product product = null;
        try {
            product = productService.findProduct(productId);
        } catch (PoductNotFoundException e) {
            return String.valueOf(ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage()));
        }
        productService.delete(product);
        return "redirect:/api/v1/products";
    }
}
