package in.ineuron.client;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name="TRIAL-SERVICE")
public interface HelloClient {

	@GetMapping("/hello/{name}")
	public String invokeString(@PathVariable String name);

}
