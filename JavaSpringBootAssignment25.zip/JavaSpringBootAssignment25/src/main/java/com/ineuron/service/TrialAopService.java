package com.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class TrialAopService {
	
    public String doSomething(String input) {
    	
    	
        return "output";
        
    }
}