package com.ineuron.assignment25;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MySpringAop {
	
    @Around("execution(* com.example.MyService.*(..))")
    public Object logMethodCall(ProceedingJoinPoint joinPoint) throws Throwable {
    	
        String methodName = joinPoint.getSignature().getName();
        
        Object[] args = joinPoint.getArgs();
        
        System.out.println("Method " + methodName + " called with args " + Arrays.toString(args));
        
        Object result = joinPoint.proceed();
        
        System.out.println("Method " + methodName + " returned " + result);
        
            return result;
            
      }
}
