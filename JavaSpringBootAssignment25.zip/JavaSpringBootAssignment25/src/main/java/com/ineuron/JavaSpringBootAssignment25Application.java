package com.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringBootAssignment25Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringBootAssignment25Application.class, args);
	}

}
